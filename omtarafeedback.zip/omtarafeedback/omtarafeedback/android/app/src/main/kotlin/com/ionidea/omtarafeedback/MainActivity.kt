package com.ionidea.omtarafeedback

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
