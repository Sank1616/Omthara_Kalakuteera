import 'dart:io';

import 'package:flutter/material.dart';
// ignore: unused_import
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';
import 'package:loader_overlay/loader_overlay.dart';
// ignore: unused_import
import 'package:omtarafeedback/feedback_page.dart';
import 'package:omtarafeedback/home_screen.dart';
// ignore: unused_import
import 'package:omtarafeedback/rating_bar.dart';
// ignore: unused_import
import 'package:omtarafeedback/thankyou_screen.dart';
// ignore: unused_import
import 'package:omtarafeedback/visitor_details.dart';
import 'package:overlay_support/overlay_support.dart';

import 'helpers/app_constant.dart';

void main() {
  HttpOverrides.global = MyHttpOverrides();
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  void initState() {
    super.initState();
    //Internet().checkInternetCon();
    InternetConnectionChecker().onStatusChange.listen((status) {
      final connected = status == InternetConnectionStatus.connected;
      showSimpleNotification(
          Text(connected
              ? "Connected to internet"
              : "Please connect to internet"),
          background: color);
    });

    //getHttp();
  }

  @override
  Widget build(BuildContext context) {
    return const OverlaySupport.global(
      child: GlobalLoaderOverlay(
        child:
            MaterialApp(debugShowCheckedModeBanner: false, home: HomeScreen()),
      ),
    );
  }
}

class MyHttpOverrides extends HttpOverrides {
  @override
  HttpClient createHttpClient(SecurityContext? context) {
    return super.createHttpClient(context)
      ..badCertificateCallback =
          (X509Certificate cert, String host, int port) => true;
  }
}
