class AllFeedbacks {
  bool? success;
  List<Feedbacks>? data;

  AllFeedbacks({this.success, this.data});

  AllFeedbacks.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    if (json['data'] != null) {
      data = <Feedbacks>[];
      json['data'].forEach((v) {
        data!.add(Feedbacks.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Feedbacks {
  int? id;
  String? name;
  String? phnNo;
  String? email;
  String? dob;
  String? wedDate;
  String? photofilename;
  double? rating;
  String? feedbackType;
  String? createdAt;
  String? updatedAt;

  Feedbacks(
      {this.id,
      this.name,
      this.phnNo,
      this.email,
      this.dob,
      this.wedDate,
      this.photofilename,
      this.rating,
      this.feedbackType,
      this.createdAt,
      this.updatedAt});

  Feedbacks.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    phnNo = json['phnNo'];
    email = json['email'];
    dob = json['dob'];
    wedDate = json['wedDate'];
    photofilename = json['photofilename'];
    rating =
        json['rating'] != null ? json['rating'].toDouble() : json['rating'];
    feedbackType = json['feedback_type'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    data['id'] = id;
    data['name'] = name;
    data['phnNo'] = phnNo;
    data['email'] = email;
    data['dob'] = dob;
    data['wedDate'] = wedDate;
    data['photofilename'] = photofilename;
    data['rating'] = rating;
    data['feedback_type'] = feedbackType;
    data['created_at'] = createdAt;
    data['updated_at'] = updatedAt;
    return data;
  }
}
