// ignore: duplicate_ignore
// ignore: file_names
// ignore_for_file: file_names

class SpecificFeedback {
  bool? success;
  FeedbackDetail? data;

  SpecificFeedback({this.success, this.data});

  SpecificFeedback.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    data = json['data'] != null ? FeedbackDetail.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class FeedbackDetail {
  int? id;
  String? name;
  String? phnNo;
  String? email;
  String? dob;
  String? wedDate;
  String? photofilename;
  double? rating;
  String? feedbackType;
  int? numOfPeople;
  String? comment;
  String? createdAt;
  String? updatedAt;
  List<Responses>? responses;

  FeedbackDetail(
      {this.id,
      this.name,
      this.phnNo,
      this.email,
      this.dob,
      this.wedDate,
      this.photofilename,
      this.rating,
      this.feedbackType,
      this.numOfPeople,
      this.comment,
      this.createdAt,
      this.updatedAt,
      this.responses});

  FeedbackDetail.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    phnNo = json['phnNo'];
    email = json['email'];
    dob = json['dob'];
    wedDate = json['wedDate'];
    photofilename = json['photofilename'];
    rating =
        json['rating'] != null ? json['rating'].toDouble() : json['rating'];
    feedbackType = json['feedback_type'];
    numOfPeople = json['num_of_people'];
    comment = json['comment'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    if (json['responses'] != null) {
      responses = <Responses>[];
      json['responses'].forEach((v) {
        responses!.add(Responses.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    data['phnNo'] = phnNo;
    data['email'] = email;
    data['dob'] = dob;
    data['wedDate'] = wedDate;
    data['photofilename'] = photofilename;
    data['rating'] = rating;
    data['feedback_type'] = feedbackType;
    data['num_of_people'] = numOfPeople;
    data['comment'] = comment;
    data['created_at'] = createdAt;
    data['updated_at'] = updatedAt;
    if (responses != null) {
      data['responses'] = responses!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Responses {
  String? question;
  String? option;
  String? createdAt;

  Responses({this.question, this.option, this.createdAt});

  Responses.fromJson(Map<String, dynamic> json) {
    question = json['question'];
    option = json['option'];
    createdAt = json['created_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['question'] = question;
    data['option'] = option;
    data['created_at'] = createdAt;
    return data;
  }
}
