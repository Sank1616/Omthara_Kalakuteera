class VisitorOneResponse {
  bool? success;
  String? status;
  String? message;
  Data? data;

  VisitorOneResponse({this.success, this.status, this.message, this.data});

  VisitorOneResponse.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    status = json['status'];
    message = json['message'];
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    data['status'] = status;
    data['message'] = message;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  int? id;
  String? name;
  String? email;
  String? number;
  String? dob;
  String? wedDate;
  // ignore: prefer_void_to_null, unnecessary_question_mark
  Null? photofilename;
  // ignore: unnecessary_question_mark, prefer_void_to_null
  Null? feedbackType;

  Data(
      {this.id,
      this.name,
      this.email,
      this.number,
      this.dob,
      this.wedDate,
      this.photofilename,
      this.feedbackType});

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    email = json['email'];
    number = json['number'];
    dob = json['dob'];
    wedDate = json['wedDate'];
    photofilename = json['photofilename'];
    feedbackType = json['feedback_type'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    data['email'] = email;
    data['number'] = number;
    data['dob'] = dob;
    data['wedDate'] = wedDate;
    data['photofilename'] = photofilename;
    data['feedback_type'] = feedbackType;
    return data;
  }
}
