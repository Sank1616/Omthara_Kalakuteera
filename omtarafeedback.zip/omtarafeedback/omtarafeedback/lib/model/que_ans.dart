class QuestionAnswer {
  bool? success;
  List<Data>? data;

  QuestionAnswer({this.success, this.data});

  QuestionAnswer.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    if (json['data'] != null) {
      data = <Data>[];
      json['data'].forEach((v) {
        data!.add(Data.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Data {
  int? id;
  int? questionNumber;
  String? question;
  String? responseType;
  int? active;
  String? createdAt;
  String? updatedAt;
  List<Options>? options;

  Data(
      {this.id,
      this.questionNumber,
      this.question,
      this.responseType,
      this.active,
      this.createdAt,
      this.updatedAt,
      this.options});

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    questionNumber = json['question_number'];
    question = json['question'];
    responseType = json['response_type'];
    active = json['active'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    if (json['options'] != null) {
      options = <Options>[];
      json['options'].forEach((v) {
        options!.add(Options.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['question_number'] = questionNumber;
    data['question'] = question;
    data['response_type'] = responseType;
    data['active'] = active;
    data['created_at'] = createdAt;
    data['updated_at'] = updatedAt;
    if (options != null) {
      data['options'] = options!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Options {
  int? id;
  int? questionId;
  String? option;
  int? active;
  DateTime? createdAt;
  DateTime? updatedAt;

  Options(
      {this.id,
      this.questionId,
      this.option,
      this.active,
      this.createdAt,
      this.updatedAt});

  Options.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    questionId = json['question_id'];
    option = json['option'];
    active = json['active'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['question_id'] = questionId;
    data['option'] = option;
    data['active'] = active;
    data['created_at'] = createdAt;
    data['updated_at'] = updatedAt;
    return data;
  }
}
