class VisitorResponseModel {
  String? status;
  String? message;
  List<Data>? data;

  VisitorResponseModel({this.status, this.message, this.data});

  VisitorResponseModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    if (json['data'] != null) {
      data = <Data>[];
      json['data'].forEach((v) {
        data!.add(Data.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['status'] = status;
    data['message'] = message;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Data {
  int? id;
  String? name;
  String? email;
  String? number;
  String? dob;
  String? wedDate;
  String? feedbackType;

  Data(
      {this.id,
      this.name,
      this.email,
      this.number,
      this.dob,
      this.wedDate,
      this.feedbackType});

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    email = json['email'];
    number = json['number'];
    dob = json['dob'];
    wedDate = json['wedDate'];
    feedbackType = json['feedback_type'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    data['email'] = email;
    data['number'] = number;
    data['dob'] = dob;
    data['wedDate'] = wedDate;
    data['feedback_type'] = feedbackType;
    return data;
  }
}
