// ignore_for_file: empty_catches, duplicate_ignore, unused_field

import 'package:flutter/material.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:omtarafeedback/camera_page.dart';
import 'package:omtarafeedback/helpers/app_constant.dart';
import 'package:omtarafeedback/helpers/responsiveWidget.dart';
import 'package:omtarafeedback/helpers/utility.dart';
import 'package:omtarafeedback/services/api.dart';
import 'package:omtarafeedback/textfeedback_screen.dart';

import 'helpers/helper_header.dart';
import 'helpers/global.dart' as global;

class FeedBack extends StatefulWidget {
  const FeedBack({Key? key}) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _FeedBackState createState() => _FeedBackState();
}

class _FeedBackState extends State<FeedBack> {
  final ApiClient _apiClient = ApiClient();

  Future<void> _textfeedbackType() async {
    context.loaderOverlay.show();
    await savetextFeedbackType();
    // ignore: use_build_context_synchronously
    context.loaderOverlay.hide();
  }

  Future<void> savetextFeedbackType() async {
    String au = await Utility().generateAuthentication();
    try {
      var response = await _apiClient.post(feebacktypeEndPoint,
          headers: authheader(au),
          body: {
            'feedback_type': 'Text Feedback',
            'feedback_id': global.feedbackId
          });
      if (response == null) {}
      try {
        if (response['success']) {
          // ignore: use_build_context_synchronously
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) {
              return const TextFeedBack();
            }),
          );
        }
      } catch (e) {}
    } catch (e) {}
  }

  final ApiClient _apiClient1 = ApiClient();

  Future<void> _videofeedbackType() async {
    context.loaderOverlay.show();
    await savevideoFeedbackType();
    // ignore: use_build_context_synchronously
    context.loaderOverlay.hide();
  }

  Future<void> savevideoFeedbackType() async {
    String au = await Utility().generateAuthentication();
    // ignore: duplicate_ignore, duplicate_ignore
    try {
      var response = await _apiClient.post(feebacktypeEndPoint,
          headers: authheader(au),
          body: {
            'feedback_type': 'Video Feedback',
            'feedback_id': global.feedbackId
          });
      if (response == null) {}
      try {
        if (response['success']) {
          // ignore: use_build_context_synchronously
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) {
              return const CameraPage();
            }),
          );
        }
      } catch (e) {}
      // ignore: empty_catches
    } catch (e) {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: DecoratedBox(
      // BoxDecoration takes the image
      decoration: const BoxDecoration(
        // Image set to background of the body
        image: DecorationImage(
            colorFilter: ColorFilter.mode(Colors.black, BlendMode.dstATop),
            image: AssetImage("assets/feedback-s.jpg"),
            fit: BoxFit.cover),
      ),
      //child:SingleChildScrollView(
      child: responsiveWidget(
        tab: Container(
            padding: const EdgeInsets.all(20.0),
            child: Center(
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    FeedbackButton(),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [videoFeedback(), textFeedback()],
                    )
                  ]),
            )),
        mobile: Container(
            padding: const EdgeInsets.all(20.0),
            child: Center(
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    FeedbackButton(),
                    // SizedBox(
                    //   height: 20,
                    // ),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        videoFeedbackPhone(),
                        const SizedBox(
                          height: 20,
                        ),
                        textFeedbackPhone()
                      ],
                    )
                  ]),
            )),
      ),
    )
        // )
        );
  }

  Column textFeedback() {
    return Column(children: [
      InkWell(
        onTap: () {
          _textfeedbackType();
        },
        child: Container(
          height: 400, width: 500,
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(40), color: color),
          //child: Image(image: ResizeImage(AssetImage('images/letter.png'),width: 300,height: 300,))
          child: const Icon(
            Icons.message_rounded,
            color: Colors.white,
            size: 300,
          ),
        ),
      ),
      const SizedBox(height: 10.0),
      const Text(
        'Write Feedback',
        style: TextStyle(fontSize: 50, color: Colors.white),
      )
    ]);
  }

  Column videoFeedback() {
    return Column(
      children: [
        InkWell(
          child: Container(
              height: 400,
              width: 500,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(40), color: color),
              child: const Image(
                  image: ResizeImage(
                AssetImage('assets/Camera logo.png'),
                width: 300,
                height: 300,
              ))),
          onTap: () {
            _videofeedbackType();
          },
        ),
        const SizedBox(height: 10.0),
        const Text(
          'Video Feedback',
          style: TextStyle(
            fontSize: 50,
            color: Colors.white,
          ),
        )
      ],
    );
  }

  Column textFeedbackPhone() {
    return Column(children: [
      InkWell(
        onTap: () {
          _textfeedbackType();
        },
        child: Container(
          height: 200, width: 300,
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(40), color: color),
          //child: Image(image: ResizeImage(AssetImage('images/letter.png'),width: 300,height: 300,))
          child: const Icon(
            Icons.message_rounded,
            color: Colors.white,
            size: 100,
          ),
        ),
      ),
      const SizedBox(height: 10.0),
      const Text(
        'Write Feedback',
        style: TextStyle(fontSize: 20, color: Colors.white),
      )
    ]);
  }

  Column videoFeedbackPhone() {
    return Column(
      children: [
        InkWell(
          child: Container(
              height: 200,
              width: 300,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(40), color: color),
              child: const Image(
                  image: ResizeImage(
                AssetImage('assets/Camera logo.png'),
                width: 100,
                height: 100,
              ))),
          onTap: () {
            _videofeedbackType();
          },
        ),
        const SizedBox(height: 10.0),
        const Text(
          'Video Feedback',
          style: TextStyle(
            fontSize: 20,
            color: Colors.white,
          ),
        )
      ],
    );
  }

  // ignore: non_constant_identifier_names
  Container FeedbackButton() {
    return Container(
      height: 100,
      width: 300,
      decoration:
          BoxDecoration(borderRadius: BorderRadius.circular(20), color: color),
      alignment: Alignment.center,
      child: const Text(
        'Feedback',
        style: TextStyle(fontSize: 50, color: Colors.white),
      ),
    );
  }
}
