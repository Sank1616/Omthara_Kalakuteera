// ignore_for_file: unused_local_variable, duplicate_ignore, unused_import

import 'package:flutter/material.dart';
import 'package:omtarafeedback/admin_feedback_lisit.dart';
import 'package:omtarafeedback/admin_login.dart';
import 'package:omtarafeedback/helpers/app_constant.dart';
import 'package:omtarafeedback/helpers/responsiveWidget.dart';
import 'package:omtarafeedback/visitor_page.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  // ignore: duplicate_ignore
  @override
  // ignore: duplicate_ignore, duplicate_ignore
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    // ignore: unused_local_variable
    Orientation orientation = MediaQuery.of(context).orientation;
    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/Welcome-screen-s.jpg'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          Align(
              alignment: Alignment.center,
              child: responsiveWidget(
                mobile: forphone(context),
                tab: fortab(context),
              )),
        ],
      ),
    );
  }

  Column fortab(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.asset(
          'assets/Omthara Logo.png',
          width: 500,
        ),
        const SizedBox(
          height: 64,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).push(MaterialPageRoute(
                    builder: (context) => const VisitorPage()));
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: color,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(40),
                ),
                padding:
                    const EdgeInsets.symmetric(vertical: 15, horizontal: 60),
              ),
              child: const Padding(
                padding: EdgeInsets.only(left: 32.0, right: 32),
                child: Row(
// ignore: prefer_const_literals_to_create_immutables
                  children: [
                    Text(
                      'Feedback',
                      style: TextStyle(
                        fontSize: 40,
//fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(
                      width: 24,
                    ),
                    Icon(
                      Icons.arrow_forward,
                      color: Colors.white,
                      size: 50,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
        const SizedBox(
          height: 64,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).push(MaterialPageRoute(
                    builder: (context) => const AdminLoginScreen()));
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: color,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(40),
                ),
                padding:
                    const EdgeInsets.symmetric(vertical: 15, horizontal: 50),
              ),
              child: const Padding(
                padding: EdgeInsets.only(left: 64.0, right: 64),
                child: Row(
// ignore: prefer_const_literals_to_create_immutables
                  children: [
                    Text(
                      'Admin',
                      style: TextStyle(
                        fontSize: 40,
//fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(
                      width: 24,
                    ),
                    Icon(
                      Icons.arrow_forward,
                      color: Colors.white,
                      size: 50,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Column forphone(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.asset(
          'assets/Omthara Logo.png',
          width: 300,
        ),
        const SizedBox(
          height: 24,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).push(MaterialPageRoute(
                    builder: (context) => const VisitorPage()));
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: color,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(40),
                ),
                padding:
                    const EdgeInsets.symmetric(vertical: 15, horizontal: 60),
              ),
              child: const Padding(
                padding: EdgeInsets.only(left: 32.0, right: 32),
                child: Row(
// ignore: prefer_const_literals_to_create_immutables
                  children: [
                    Text(
                      'Feedback',
                      style: TextStyle(
                        fontSize: 20,
//fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(
                      width: 14,
                    ),
                    Icon(
                      Icons.arrow_forward,
                      color: Colors.white,
                      size: 20,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
        const SizedBox(
          height: 24,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).push(MaterialPageRoute(
                    builder: (context) => const AdminLoginScreen()));
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: color,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(40),
                ),
                padding:
                    const EdgeInsets.symmetric(vertical: 15, horizontal: 60),
              ),
              child: const Padding(
                padding: EdgeInsets.only(left: 50.0, right: 50),
                child: Row(
// ignore: prefer_const_literals_to_create_immutables
                  children: [
                    Text(
                      'Admin',
                      style: TextStyle(
                        fontSize: 20,
//fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(
                      width: 14,
                    ),
                    Icon(
                      Icons.arrow_forward,
                      color: Colors.white,
                      size: 20,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}







// Column(
// mainAxisAlignment: MainAxisAlignment.center,
// children: [
// Image.asset(
// 'assets/Omthara Logo.png',
// width: 500,
// ),
// const SizedBox(
// height: 64,
// ),
// Row(
// mainAxisAlignment: MainAxisAlignment.center,
// children: [
// ElevatedButton(
// onPressed: () {
// Navigator.of(context).push(MaterialPageRoute(
// builder: (context) => const VisitorPage()));
// },
// style: ElevatedButton.styleFrom(
// backgroundColor: color,
// shape: RoundedRectangleBorder(
// borderRadius: BorderRadius.circular(40),
// ),
// padding: const EdgeInsets.symmetric(
// vertical: 15, horizontal: 60),
// ),
// child: Padding(
// padding: const EdgeInsets.only(left: 32.0, right: 32),
// child: Row(
// // ignore: prefer_const_literals_to_create_immutables
// children: [
// const Text(
// 'Feedback',
// style: TextStyle(
// fontSize: 40,
// //fontWeight: FontWeight.bold,
// ),
// ),
// const SizedBox(
// width: 24,
// ),
// const Icon(
// Icons.arrow_forward,
// color: Colors.white,
// size: 50,
// ),
// ],
// ),
// ),
// ),
// ],
// ),
// const SizedBox(
// height: 64,
// ),
// Row(
// mainAxisAlignment: MainAxisAlignment.center,
// children: [
// ElevatedButton(
// onPressed: () {
// Navigator.of(context).push(MaterialPageRoute(
// builder: (context) => const AdminLoginScreen()));
// },
// style: ElevatedButton.styleFrom(
// backgroundColor: color,
// shape: RoundedRectangleBorder(
// borderRadius: BorderRadius.circular(40),
// ),
// padding: const EdgeInsets.symmetric(
// vertical: 15, horizontal: 60),
// ),
// child: Padding(
// padding: const EdgeInsets.only(left: 60.0, right: 60),
// child: Row(
// // ignore: prefer_const_literals_to_create_immutables
// children: [
// const Text(
// 'Admin',
// style: TextStyle(
// fontSize: 40,
// //fontWeight: FontWeight.bold,
// ),
// ),
// const SizedBox(
// width: 24,
// ),
// const Icon(
// Icons.arrow_forward,
// color: Colors.white,
// size: 50,
// ),
// ],
// ),
// ),
// ),
// ],
// ),
// ],
// ),
