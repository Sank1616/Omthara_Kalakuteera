// ignore_for_file: use_build_context_synchronously

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:omtarafeedback/helpers/fields_calender.dart';
import 'package:omtarafeedback/helpers/app_constant.dart';
import 'package:omtarafeedback/helpers/fields.dart';
import 'package:omtarafeedback/helpers/utility.dart';
import 'package:omtarafeedback/model/visitorone_response.dart';
import 'package:omtarafeedback/services/api.dart';
import 'package:omtarafeedback/visitor_details.dart';
import 'helpers/global.dart' as global;
import 'helpers/helper_header.dart';
import 'helpers/responsiveWidget.dart';

class VisitorPage extends StatefulWidget {
  const VisitorPage({Key? key}) : super(key: key);

  @override
  State<VisitorPage> createState() => _VisitorPageState();
}

class _VisitorPageState extends State<VisitorPage> {
  final ApiClient _apiClient = ApiClient();
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _name = TextEditingController();
  final TextEditingController _phno = TextEditingController();
  final TextEditingController _email = TextEditingController();
  final TextEditingController _dobController = TextEditingController();
  final TextEditingController _weddController = TextEditingController();

  @override
  void dispose() {
    _name.dispose();
    _phno.dispose();
    _email.dispose();
    _dobController.dispose();
    _weddController.dispose();
    super.dispose();
  }

  void saveFeedback() async {
    context.loaderOverlay.show();
    await feedbackapiCall();

    context.loaderOverlay.hide();
  }

  Future<void> feedbackapiCall() async {
    String au = await Utility().generateAuthentication();
    final DateFormat displayFormater = DateFormat('yyyy-MM-dd');
    // ignore: unused_local_variable
    DateTime dob = displayFormater.parse(_dobController.text);
    // ignore: unused_local_variable
    DateTime wed = displayFormater.parse(_weddController.text);
    try {
      var response = await _apiClient
          .formPost(saveFeedBackEndPoint, headers: authheader(au), body: {
        'name': _name.text,
        'phone': _phno.text,
        'email': _email.text,
        'dob': _dobController.text,
        'wed_date': _weddController.text,
      });
      if (response == null) {
        // ignore: avoid_print
        print("Empty response");
      }
      try {
        VisitorOneResponse visitor = VisitorOneResponse.fromJson(response);
        if (visitor.success!) {
          if (visitor.data!.id != null) {
            global.feedbackId = visitor.data!.id!;
            Navigator.of(context).push(MaterialPageRoute(
                builder: (context) => const VisitorDetails()));
          }
        }
      } catch (e) {
        // ignore: avoid_print
        print("Erro:${e.toString()}");
      }
    } catch (e) {
      // ignore: avoid_print
      print("Erro:${e.toString()}");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage("assets/personal-info2-s.jpg"),
                fit: BoxFit.fill,
              ),
            ),
          ),
          InkWell(
            onTap: () {
              FocusScope.of(context).unfocus();
            },
            child: SingleChildScrollView(
              child: responsiveWidget(
                  mobile: detailsPhone(context), tab: detailsTab(context)),
            ),
          ),
        ],
      ),
    );
  }

  Column detailsPhone(BuildContext context) {
    return Column(
      children: [
        Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              const SizedBox(
                height: 50,
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  height: 52,
                  width: 190,
                  padding: const EdgeInsets.all(11),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30), color: color),
                  child: const Text(
                    'Visitor Details',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 25,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              const SizedBox(
                height: 15,
              ),
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 15, left: 10),
                    child: SizedBox(
                      height: 55,
                      child: InputField(
                        FontSize: 20,
                        controller: _name,
                        label: 'Name',
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'This field cannot be empty';
                          }
                          return null;
                        },
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 15,
              ),
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 25, left: 10),
                    child: SizedBox(
                      height: 55,
                      child: InputField(
                        FontSize: 20,
                        controller: _phno,
                        label: 'Phone Number',
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'This field cannot be empty';
                          }
                          return null;
                        },
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 15,
              ),
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 25, left: 10),
                    child: SizedBox(
                      height: 55,
                      child: InputField(
                        FontSize: 20,
                        controller: _email,
                        label: 'Email',
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'This field cannot be empty';
                          }
                          return null;
                        },
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 15,
              ),
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 25, left: 8),
                    child: SizedBox(
                      height: 55,
                      child: CalenderFields(
                        controller: _dobController,
                        label: 'Birthday',
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'This field cannot be empty';
                          }
                          return null;
                        },
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 15,
              ),
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 25, left: 10),
                    child: SizedBox(
                      height: 55,
                      child: CalenderFields(
                        controller: _weddController,
                        label: 'Wedding Anniversary',
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'This field cannot be empty';
                          }
                          return null;
                        },
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 15,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Container(
                    margin: const EdgeInsets.only(top: 20, right: 10),
                    child: ElevatedButton(
                      onPressed: () {
                        if (_formKey.currentState!.validate()) {
                          saveFeedback();
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: color,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(40),
                        ),
                        padding: const EdgeInsets.symmetric(
                          vertical: 10,
                        ),
                      ),
                      // ignore: prefer_const_constructors
                      child: Padding(
                        padding: const EdgeInsets.only(left: 20.0, right: 30),
                        // ignore: prefer_const_constructors
                        child: Row(
                          // ignore: prefer_const_literals_to_create_immutables
                          children: [
                            const Padding(
                              padding: EdgeInsets.only(left: 15, right: 2),
                              child: Text(
                                'Next',
                                style: TextStyle(
                                  fontSize: 25,
                                  //fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            const SizedBox(
                              width: 14,
                            ),
                            const Icon(
                              Icons.arrow_forward,
                              color: Colors.white,
                              size: 25,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 10,
              ),
            ],
          ),
        ),
      ],
    );
  }

  Form detailsTab(BuildContext context) {
    return Form(
      key: _formKey,
      child: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            const SizedBox(
              height: 32,
            ),
            Container(
              alignment: Alignment.center,
              height: 50,
              width: 250,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20), color: color),
              child: const Text(
                'Visitor Details',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(height: 32),
            Row(
              children: [
                InputField(
                  FontSize: 32,
                  controller: _name,
                  label: 'Name',
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'This field cannot be empty';
                    }
                    return null;
                  },
                ),
              ],
            ),
            const SizedBox(
              height: 32,
            ),
            Row(
              children: [
                InputField(
                  FontSize: 32,
                  controller: _phno,
                  label: 'Phone Number',
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'This field cannot be empty';
                    }
                    return null;
                  },
                ),
              ],
            ),
            const SizedBox(
              height: 32,
            ),
            Row(
              children: [
                InputField(
                  FontSize: 32,
                  controller: _email,
                  label: 'Email',
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'This field cannot be empty';
                    }
                    return null;
                  },
                ),
              ],
            ),
            const SizedBox(
              height: 32,
            ),
            Row(
              children: [
                CalenderFields(
                  controller: _dobController,
                  label: 'Birthday',
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'This field cannot be empty';
                    }
                    return null;
                  },
                ),
              ],
            ),
            const SizedBox(
              height: 32,
            ),
            Row(
              children: [
                CalenderFields(
                  controller: _weddController,
                  label: 'Wedding Anniversary',
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'This field cannot be empty';
                    }
                    return null;
                  },
                ),
              ],
            ),
            const SizedBox(
              height: 64,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                ElevatedButton(
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      saveFeedback();
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: color,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(40),
                    ),
                    padding: const EdgeInsets.symmetric(
                        vertical: 15, horizontal: 60),
                  ),
                  // ignore: prefer_const_constructors
                  child: Padding(
                    padding: const EdgeInsets.only(left: 32.0, right: 32),
                    // ignore: prefer_const_constructors
                    child: Row(
                      // ignore: prefer_const_literals_to_create_immutables
                      children: [
                        const Text(
                          'Next',
                          style: TextStyle(
                            fontSize: 40,
                            //fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(
                          width: 24,
                        ),
                        const Icon(
                          Icons.arrow_forward,
                          color: Colors.white,
                          size: 50,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
