import 'package:flutter/material.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:omtarafeedback/details.dart';
import 'package:omtarafeedback/helpers/helper_header.dart';
import 'package:omtarafeedback/services/api.dart';
import 'helpers/app_constant.dart';
import 'helpers/responsiveWidget.dart';
import 'model/list_feedback_admin.dart';

class AdminFeedbackList extends StatefulWidget {
  const AdminFeedbackList({Key? key}) : super(key: key);

  @override
  State<AdminFeedbackList> createState() => _AdminFeedbackListState();
}

class _AdminFeedbackListState extends State<AdminFeedbackList> {
  bool isLoaded = true;
  final ApiClient _apiClient = ApiClient();
  List<Feedbacks> sample = [];

  @override
  void initState() {
    super.initState();
    callEndpoint();
  }

  Future<void> callEndpoint() async {
    context.loaderOverlay.show();
    await _displayList();
    // ignore: use_build_context_synchronously
    context.loaderOverlay.hide();
  }

  Future<void> _displayList() async {
    try {
      var response = await _apiClient.get(listFeedback, headers: header());
      if (response == null) {
        // ignore: avoid_print
        print("Empty response");
      }
      try {
        AllFeedbacks feedBackList = AllFeedbacks.fromJson(response);
        if (feedBackList.data!.isNotEmpty && feedBackList.success == true) {
          setState(() {
            sample.clear();
            sample = feedBackList.data!;
          });
        }
      } catch (e) {
        // ignore: avoid_print
        print("Error:$e");
        throw Exception("Failed");
      }
    } catch (e) {
      // ignore: avoid_print
      print("Error:$e");
      throw Exception("Failed");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(children: [
        Container(
          decoration: const BoxDecoration(
            image: DecorationImage(
              image: AssetImage('assets/Visit-info-s.jpg'),
              fit: BoxFit.cover,
            ),
          ),
        ),
        responsiveWidget(mobile: adminfeedbackPhone(), tab: adminfeedbackTab())
      ]),
    );
  }

  ListView adminfeedbackPhone() {
    return ListView.builder(
      itemCount: sample.length,
      itemBuilder: (context, index) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 5.0),
          child: GestureDetector(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(80),
                color: const Color.fromARGB(255, 243, 227, 227),
              ),
              padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 40),
              margin: const EdgeInsets.all(10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'Name: ',
                            style: TextStyle(
                              decoration: TextDecoration.none,
                              fontSize: 18,
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            '${sample[index].name}',
                            style: const TextStyle(
                              fontSize: 18,
                              color: Color(0xFFee7421),
                              decoration: TextDecoration.none,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 8,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'Phone Number: ',
                            style: TextStyle(
                              decoration: TextDecoration.none,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.black,
                            ),
                          ),
                          Text(
                            '${sample[index].phnNo}',
                            style: const TextStyle(
                              fontSize: 18,
                              color: Color(0xFFee7421),
                              decoration: TextDecoration.none,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 8,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'Email: ',
                            style: TextStyle(
                              decoration: TextDecoration.none,
                              fontSize: 18,
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            '${sample[index].email}',
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              color: Color(0xFFee7421),
                              fontSize: 18,
                              decoration: TextDecoration.none,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 8,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'Rating: ',
                            style: TextStyle(
                              decoration: TextDecoration.none,
                              fontSize: 18,
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            '${sample[index].rating ?? 0}',
                            style: const TextStyle(
                              color: Color(0xFFee7421),
                              fontSize: 18,
                              decoration: TextDecoration.none,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const Text('>',
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 32,
                        decoration: TextDecoration.none,
                        fontWeight: FontWeight.bold,
                      )),
                ],
              ),
            ),
            onTap: () {
              Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => DetailScreen(
                        id: sample[index].id!,
                      )));
            },
          ),
        );
      },
    );
  }

  ListView adminfeedbackTab() {
    return ListView.builder(
      itemCount: sample.length,
      itemBuilder: (context, index) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32.0),
          child: GestureDetector(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(90),
                color: const Color.fromARGB(255, 243, 227, 227),
              ),
              padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 64),
              margin: const EdgeInsets.all(10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'Name: ',
                            style: TextStyle(
                              decoration: TextDecoration.none,
                              fontSize: 24,
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            '${sample[index].name}',
                            style: const TextStyle(
                              fontSize: 24,
                              color: Color(0xFFee7421),
                              decoration: TextDecoration.none,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 8,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'Phone Number: ',
                            style: TextStyle(
                              decoration: TextDecoration.none,
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                              color: Colors.black,
                            ),
                          ),
                          Text(
                            '${sample[index].phnNo}',
                            style: const TextStyle(
                              fontSize: 24,
                              color: Color(0xFFee7421),
                              decoration: TextDecoration.none,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 8,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'Email: ',
                            style: TextStyle(
                              decoration: TextDecoration.none,
                              fontSize: 24,
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            '${sample[index].email}',
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              color: Color(0xFFee7421),
                              fontSize: 24,
                              decoration: TextDecoration.none,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 8,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'Rating: ',
                            style: TextStyle(
                              decoration: TextDecoration.none,
                              fontSize: 24,
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            '${sample[index].rating ?? 0}',
                            style: const TextStyle(
                              color: Color(0xFFee7421),
                              fontSize: 24,
                              decoration: TextDecoration.none,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const Text('>',
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 32,
                        decoration: TextDecoration.none,
                        fontWeight: FontWeight.bold,
                      )),
                ],
              ),
            ),
            onTap: () {
              Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => DetailScreen(
                        id: sample[index].id!,
                      )));
            },
          ),
        );
      },
    );
  }
}
