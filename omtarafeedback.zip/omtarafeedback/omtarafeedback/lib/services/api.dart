// ignore: duplicate_ignore
// ignore: duplicate_ignore
// ignore: duplicate_ignore
// ignore: duplicate_ignore
// ignore: duplicate_ignore
// ignore: duplicate_ignore
// ignore: duplicate_ignore
// ignore: duplicate_ignore
// ignore: duplicate_ignore
// ignore: duplicate_ignore
// ignore: duplicate_ignore
// ignore: duplicate_ignore
// ignore: duplicate_ignore
// ignore: duplicate_ignore
// ignore: duplicate_ignore
// ignore_for_file: prefer_typing_uninitialized_variables, duplicate_ignore

import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:omtarafeedback/helpers/app_constant.dart';
import 'package:overlay_support/overlay_support.dart';
// ignore: unused_import
import 'package:toast/toast.dart' as toast;

final dio = Dio();

// ignore: duplicate_ignore, duplicate_ignore
class ApiClient {
  static const String baseUrl = 'http://52.66.214.85/api/';

  // ignore: duplicate_ignore, duplicate_ignore
  Future<dynamic> get(String endpoint,
      {Map<String, String>? headers,
      // ignore: duplicate_ignore, duplicate_ignore
      Map<String, dynamic>? queryParameters}) async {
    // ignore: prefer_typing_uninitialized_variables
    var responseJson;
    try {
      final response = await dio.get(baseUrl + endpoint,
          queryParameters: queryParameters, options: Options(headers: headers));

      responseJson = handleResponse(response);
    } on DioError catch (e) {
      responseJson = handleResponse(e.response!);
      debugPrint("error:${e.toString()}");
      // throw e;
    }

    return responseJson;
  }

  Future<dynamic> post(String endpoint,
      {Map<String, String>? headers, Map<String, dynamic>? body}) async {
    // ignore: prefer_typing_uninitialized_variables
    var responseJson;
    try {
      final response = await dio.post(baseUrl + endpoint,
          options: Options(headers: headers), data: jsonEncode(body));

      responseJson = handleResponse(response);
    } on DioError catch (e) {
      responseJson = handleResponse(e.response!);
      debugPrint("error:${e.toString()}");
      //throw e;
    }

    return responseJson;
  }

  Future<dynamic> formPost(String endpoint,
      {Map<String, String>? headers, Map<String, dynamic>? body}) async {
    // ignore: prefer_typing_uninitialized_variables
    FormData formData = FormData.fromMap(body!);
    var responseJson;
    try {
      final response = await dio.post(baseUrl + endpoint,
          options: Options(headers: headers), data: formData);

      responseJson = handleResponse(response);
    } on DioError catch (e) {
      responseJson = handleResponse(e.response!);
      debugPrint("error:${e.response.toString()}");
      //throw e;
    }

    return responseJson;
  }

  dynamic handleResponse(Response response) {
    switch (response.statusCode) {
      case 200:
        return response.data;
      case 201:
        return response.data;
      case 302:
        throw UnimplementedError();
      case 400:
        showSimpleNotification(Text(response.data["message"]),
            background: color);
        break;
      //return response.data;
      case 401:
        showSimpleNotification(Text(response.data["message"]),
            background: color);

        break;
      case 403:
        showSimpleNotification(Text(response.data["message"]),
            background: color);
        break;
      case 404:
        showSimpleNotification(Text(response.data["message"]),
            background: color);
        break;
      case 405:
        showSimpleNotification(Text(response.data["message"]),
            background: color);
        break;
      case 422:
        showSimpleNotification(Text(response.data["message"]),
            background: color);

        break;
      default:
    }
  }

  void showToast(String msg, {int? duration, int? gravity}) {
    // toast.show(msg, duration: duration, gravity: gravity);
  }
}
