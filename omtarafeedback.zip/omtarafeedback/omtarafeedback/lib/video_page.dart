//import 'dart:html' as h;
import 'dart:io' as i;
// ignore: unused_import
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:omtarafeedback/helpers/buttons.dart';
import 'package:omtarafeedback/rating_bar.dart';
// ignore: unused_import
import 'package:omtarafeedback/helpers/app_constant.dart';
import 'package:video_player/video_player.dart';

class VideoPage extends StatefulWidget {
  final String filePath;

  const VideoPage({Key? key, required this.filePath}) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _VideoPageState createState() => _VideoPageState();
}

class _VideoPageState extends State<VideoPage> {
  late VideoPlayerController _videoPlayerController;

  @override
  void dispose() {
    _videoPlayerController.dispose();
    super.dispose();
  }

  Future _initVideoPlayer() async {
    _videoPlayerController =
        VideoPlayerController.file(i.File(widget.filePath));
    await _videoPlayerController.initialize();
    await _videoPlayerController.setLooping(true);
    await _videoPlayerController.play();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Preview'),
        elevation: 0,
        backgroundColor: Colors.black26,
        actions: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              myButton(
                  text: 'Submit',
                  tapped: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) {
                        // ignore: prefer_const_constructors
                        return RatingBarScreen();
                      }),
                    );
                  }),

              // ignore: prefer_const_constructors
              SizedBox(
                width: 50,
              )
            ],
          )
        ],
      ),
      extendBodyBehindAppBar: true,
      body: FutureBuilder(
        future: _initVideoPlayer(),
        builder: (context, state) {
          if (state.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else {
            return VideoPlayer(_videoPlayerController);
          }
        },
      ),
    );
  }
}
