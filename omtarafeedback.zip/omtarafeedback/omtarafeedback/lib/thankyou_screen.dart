import 'package:flutter/material.dart';
import 'package:omtarafeedback/helpers/app_constant.dart';

import 'helpers/responsiveWidget.dart';

class ThankYou extends StatelessWidget {
  const ThankYou({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: responsiveWidget(
            mobile: thankyouPhone(context), tab: thankyouTab(context)));
  }

  Stack thankyouPhone(BuildContext context) {
    return Stack(
      children: [
        Container(
          color: Colors.white,
        ),
        Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            // ignore: avoid_unnecessary_containers
            child: Container(
              child: Image.asset('assets/Omthara Logo.png'),
            ),
          ),
        ),
        GestureDetector(
          onTap: () {
            Navigator.popUntil(
                context, (Route<dynamic> predicate) => predicate.isFirst);
          },
          child: Padding(
            padding: const EdgeInsets.only(top: 480, left: 120),
            child: Container(
              height: 60,
              width: 190,
              decoration: BoxDecoration(
                  color: color, borderRadius: BorderRadius.circular(15.0)),
              child: const Center(
                child: Text(
                  "Thank You",
                  style: TextStyle(
                      fontSize: 30,
                      color: Colors.white,
                      fontWeight: FontWeight.w500,
                      fontFamily: 'FontMain'),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Stack thankyouTab(BuildContext context) {
    return Stack(
      children: [
        Container(
          color: Colors.white,
        ),
        Center(
          child: Container(
            margin: const EdgeInsets.only(bottom: 180),
            child: Image.asset('assets/Omthara Logo.png'),
          ),
        ),
        GestureDetector(
          onTap: () {
            Navigator.popUntil(
                context, (Route<dynamic> predicate) => predicate.isFirst);
          },
          child: Container(
            margin: const EdgeInsets.only(top: 470, left: 460),
            height: 100,
            width: 370,
            decoration: BoxDecoration(
                color: color, borderRadius: BorderRadius.circular(25.0)),
            child: const Center(
              child: Text(
                "Thank You",
                style: TextStyle(
                    fontSize: 55,
                    color: Colors.white,
                    fontWeight: FontWeight.w500,
                    fontFamily: 'FontMain'),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
