import 'package:flutter/material.dart';
import 'package:omtarafeedback/admin_feedback_lisit.dart';
import 'package:omtarafeedback/helpers/app_constant.dart';
import 'package:overlay_support/overlay_support.dart';

import 'helpers/responsiveWidget.dart';

class AdminLoginScreen extends StatefulWidget {
  const AdminLoginScreen({super.key});

  @override
  State<AdminLoginScreen> createState() => _AdminLoginScreenState();
}

class _AdminLoginScreenState extends State<AdminLoginScreen> {
  final TextEditingController _emailTextField = TextEditingController();
  final TextEditingController _passwordTextField = TextEditingController();
  // ignore: unused_field
  final _formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    _emailTextField.dispose();
    _passwordTextField.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
                image: DecorationImage(
                    image: AssetImage('assets/personal-info2-s.jpg'),
                    fit: BoxFit.cover)),
          ),
          responsiveWidget(mobile: adminloginPhone(), tab: adminloginTab())
        ],
      ),
    );
  }

  Column adminloginPhone() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        const Center(
          child: Text(
            'Login',
            style: TextStyle(
                fontFamily: 'FontStyle',
                fontSize: 45,
                fontWeight: FontWeight.w500,
                color: Colors.white),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 30),
          child: Form(
              key: _formKey,
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: TextFormField(
                      controller: _emailTextField,
                      keyboardType: TextInputType.emailAddress,
                      style: const TextStyle(color: Colors.white, fontSize: 20),
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.email, color: Colors.white70),
                        labelText: 'Email',
                        labelStyle:
                            TextStyle(color: Colors.white, fontSize: 20),
                        hintText: 'Enter Email',
                        hintStyle: TextStyle(color: Colors.white, fontSize: 20),
                        focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                          width: 1.5,
                          color: Colors.deepOrangeAccent,
                        )),
                        enabledBorder: OutlineInputBorder(
                            borderSide:
                                BorderSide(width: 1.5, color: Colors.white60)),
                      ),
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'This field cannnot be empty';
                        }
                        return null;
                      },
                    ),
                  ),

                  const SizedBox(
                    height: 25,
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: TextFormField(
                      controller: _passwordTextField,
                      keyboardType: TextInputType.visiblePassword,
                      style: const TextStyle(color: Colors.white, fontSize: 20),
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(
                          Icons.password,
                          color: Colors.white70,
                        ),
                        labelText: 'Password',
                        labelStyle:
                            TextStyle(color: Colors.white, fontSize: 20),
                        hintText: 'Enter Password',
                        hintStyle: TextStyle(color: Colors.white, fontSize: 20),
                        focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                width: 1.5, color: Colors.deepOrangeAccent)),
                        enabledBorder: OutlineInputBorder(
                            borderSide:
                                BorderSide(width: 1.5, color: Colors.white60)),
                      ),
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'this field cannot be empty';
                        }
                        return null;
                      },
                    ),
                  ),

                  const SizedBox(
                    height: 35,
                  ),
                  // ignore: sort_child_properties_last
                  ElevatedButton(
                    onPressed: () {
                      if (_formKey.currentState!.validate()) {
                        if (_emailTextField.text == 'admin@gmail.com' &&
                            _passwordTextField.text == 'admin@123') {
                          Navigator.of(context).push(MaterialPageRoute(
                              builder: (context) => const AdminFeedbackList()));
                        } else {
                          showSimpleNotification(const Text('User is invalid'),
                              background: color);
                        }
                      }
                    },
                    // ignore: sort_child_properties_last
                    child: const Text(
                      'Login',
                      style: TextStyle(
                          fontWeight: FontWeight.w500,
                          color: Colors.white,
                          fontSize: 35,
                          fontFamily: 'FontMain'),
                    ),
                    style: ElevatedButton.styleFrom(
                        minimumSize: const Size(170, 50),
                        // ignore: deprecated_member_use
                        primary: Colors.orangeAccent[700],
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(40))),
                  ),
                ],
              )),
        )
      ],
    );
  }

  Column adminloginTab() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        const Center(
          child: Text(
            'Login',
            style: TextStyle(
                fontFamily: 'FontStyle',
                fontSize: 70,
                fontWeight: FontWeight.w500,
                color: Colors.white),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 30),
          child: Form(
              key: _formKey,
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 300),
                    child: TextFormField(
                      controller: _emailTextField,
                      keyboardType: TextInputType.emailAddress,
                      style: const TextStyle(color: Colors.white, fontSize: 20),
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.email, color: Colors.white70),
                        labelText: 'Email',
                        labelStyle:
                            TextStyle(color: Colors.white, fontSize: 20),
                        hintText: 'Enter Email',
                        hintStyle: TextStyle(color: Colors.white, fontSize: 20),
                        focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                          width: 1.5,
                          color: Colors.deepOrangeAccent,
                        )),
                        enabledBorder: OutlineInputBorder(
                            borderSide:
                                BorderSide(width: 1.5, color: Colors.white60)),
                      ),
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'This field cannnot be empty';
                        }
                        return null;
                      },
                    ),
                  ),
                  const SizedBox(
                    height: 25,
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 300),
                    child: TextFormField(
                      controller: _passwordTextField,
                      keyboardType: TextInputType.visiblePassword,
                      style: const TextStyle(color: Colors.white, fontSize: 20),
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(
                          Icons.password,
                          color: Colors.white70,
                        ),
                        labelText: 'Password',
                        labelStyle:
                            TextStyle(color: Colors.white, fontSize: 20),
                        hintText: 'Enter Password',
                        hintStyle: TextStyle(color: Colors.white, fontSize: 20),
                        focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                width: 1.5, color: Colors.deepOrangeAccent)),
                        enabledBorder: OutlineInputBorder(
                            borderSide:
                                BorderSide(width: 1.5, color: Colors.white60)),
                      ),
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'this field cannot be empty';
                        }
                        return null;
                      },
                    ),
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  // ignore: sort_child_properties_last
                  ElevatedButton(
                    onPressed: () {
                      if (_formKey.currentState!.validate()) {
                        if (_emailTextField.text == 'admin@gmail.com' &&
                            _passwordTextField.text == 'admin@123') {
                          Navigator.of(context).push(MaterialPageRoute(
                              builder: (context) => const AdminFeedbackList()));
                        } else {
                          showSimpleNotification(const Text('User is invalid'),
                              background: color);
                        }
                      }
                    },
                    // ignore: sort_child_properties_last
                    child: const Text(
                      'Login',
                      style: TextStyle(
                          fontWeight: FontWeight.w500,
                          color: Colors.white,
                          fontSize: 50,
                          fontFamily: 'FontMain'),
                    ),
                    style: ElevatedButton.styleFrom(
                        minimumSize: const Size(270, 65),
                        // ignore: deprecated_member_use
                        primary: Colors.orangeAccent[700],
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(40))),
                  ),
                ],
              )),
        )
      ],
    );
  }
}
