// ignore_for_file: avoid_print, use_build_context_synchronously

import 'package:flutter/material.dart';
import 'package:omtarafeedback/helpers/app_constant.dart';
import 'package:omtarafeedback/helpers/helper_header.dart';
import 'package:omtarafeedback/helpers/utility.dart';
import 'package:omtarafeedback/model/que_ans.dart';
import 'package:omtarafeedback/rating_bar.dart';
import 'package:omtarafeedback/services/api.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'helpers/global.dart' as global;
import 'helpers/responsiveWidget.dart';

class TextFeedBack extends StatefulWidget {
  const TextFeedBack({Key? key}) : super(key: key);

  @override
  State<TextFeedBack> createState() => _TextFeedBackState();
}

class _TextFeedBackState extends State<TextFeedBack> {
  final _formKey = GlobalKey<FormState>();
  final ApiClient _apiClient = ApiClient();
  QuestionAnswer _question = QuestionAnswer();
  List<Options> optionalAnswers = [];

  @override
  void initState() {
    super.initState();
    callEndPoint();
  }

  Future<void> callEndPoint() async {
    context.loaderOverlay.show();
    await _getQuestions();
    context.loaderOverlay.hide();
  }

  Future<void> _getQuestions() async {
    try {
      var response = await _apiClient.get(questionEndPoint, headers: header());
      if (response == null) {
        print("Empty response");
      }
      try {
        QuestionAnswer questions = QuestionAnswer.fromJson(response);
        if (questions.data!.isNotEmpty && questions.success == true) {
          setState(() {
            optionalAnswers =
                List.generate(questions.data!.length, (index) => Options());
            _question = questions;
            print(_question);
          });
        }
      } catch (e) {
        print("Erro:${e.toString()}");
      }
    } catch (e) {
      print("Erro:${e.toString()}");
    }
  }

  Future<void> _submitAnswers() async {
    context.loaderOverlay.show();
    await uploadAnswer();
    context.loaderOverlay.hide();
  }

  Future<void> uploadAnswer() async {
    String au = await Utility().generateAuthentication();
    List<Map<String, dynamic>> answers = [];
    for (Options item in optionalAnswers) {
      if (item.id != null) {
        answers.add({
          'question_id': item.questionId,
          'option_id': [item.id]
        });
      }
    }
    try {
      var response = await _apiClient.post(answersEndPoint,
          headers: authheader(au),
          body: {'responses': answers, 'feedback_id': global.feedbackId});
      if (response == null) {
        print("Empty response");
      }
      try {
        print(response);
        Navigator.of(context).push(
            MaterialPageRoute(builder: (context) => const RatingBarScreen()));
      } catch (e) {
        print("Erro:${e.toString()}");
      }
    } catch (e) {
      print("Erro:${e.toString()}");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Stack(
          children: [
            Container(
                decoration: const BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage("assets/text-review-s.jpg"),
                    fit: BoxFit.fill,
                  ),
                ),
                child: responsiveWidget(
                    mobile: textfeedbackPhone(), tab: textfeedbackTab())),
          ],
        ),
      ),
    );
  }

  Column textfeedbackPhone() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 60, left: 20),
          child: Container(
            width: 200,
            height: 50,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: color,
            ),
            child: const Center(
              child: Padding(
                padding: EdgeInsets.only(top: 8.0, bottom: 8.0),
                child: Text(
                  'Feedback',
                  style: TextStyle(
                    fontSize: 25,
                    color: Colors.white,
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ),
            ),
          ),
        ),
        Form(
          key: _formKey,
          child: Padding(
            padding: const EdgeInsets.only(left: 20, right: 20),
            child: ListView.builder(
              shrinkWrap: true,
              physics: const BouncingScrollPhysics(),
              itemCount: _question.data?.length ?? 0,
              itemBuilder: (BuildContext context, int index) {
                final questionData = _question.data?[index];
                return Column(
                  children: [
                    const SizedBox(
                      height: 5,
                    ),
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        color: color,
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Text(
                          'Q${questionData?.questionNumber!}: ${questionData?.question!}',
                          style: const TextStyle(
                            fontSize: 20,
                            color: Colors.white,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    // ignore: avoid_function_literals_in_foreach_calls
                    for (Options opt in questionData?.options ?? [])
                      questionData?.responseType == 'single_choice'
                          ? RadioListTile(
                              title: Text(
                                opt.option.toString(),
                                style: const TextStyle(
                                    color: Colors.white, fontSize: 20),
                              ),
                              value: opt,
                              groupValue: optionalAnswers[index],
                              activeColor: color,
                              selectedTileColor: color,
                              onChanged: (value) {
                                setState(() {
                                  optionalAnswers[index] = value as Options;
                                  //_answers[index] = value as String;
                                });
                              },
                            )
                          : questionData?.responseType == 'multiple_choice'
                              ? CheckboxListTile(
                                  title: Text(
                                    opt.option.toString(),
                                    style: const TextStyle(
                                        color: Colors.white, fontSize: 24),
                                  ),
                                  value: true,
                                  activeColor: color,
                                  checkColor: Colors.white,
                                  onChanged: (value) {
                                    setState(() {
                                      optionalAnswers[index] = value as Options;
                                    });
                                  },
                                )
                              : Container(),

                    const SizedBox(
                      height: 20,
                    ),
                  ],
                );
              },
            ),
          ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(''),
            Padding(
              padding: const EdgeInsets.only(right: 20.0),
              child: ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    _formKey.currentState!.save();
                  }
                  print(optionalAnswers);
                  _submitAnswers();
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: color,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(40),
                  ),
                  padding:
                      const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                ),
                // ignore: prefer_const_constructors
                child: Padding(
                  padding: const EdgeInsets.only(left: 22.0, right: 22),
                  // ignore: prefer_const_constructors
                  child: Row(
                    // ignore: prefer_const_literals_to_create_immutables
                    children: [
                      const Text(
                        'Submit',
                        style: TextStyle(
                          fontSize: 25,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(
          height: 32,
        ),
      ],
    );
  }

  Column textfeedbackTab() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(
          height: 32,
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 60.0, vertical: 30),
          child: Container(
            width: 250,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: color,
            ),
            child: const Center(
              child: Padding(
                padding: EdgeInsets.only(top: 8.0, bottom: 8.0),
                child: Text(
                  'Feedback',
                  style: TextStyle(
                    fontSize: 40,
                    color: Colors.white,
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ),
            ),
          ),
        ),
        Form(
          key: _formKey,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 60.0),
            child: ListView.builder(
              shrinkWrap: true,
              physics: const BouncingScrollPhysics(),
              itemCount: _question.data?.length ?? 0,
              itemBuilder: (BuildContext context, int index) {
                final questionData = _question.data?[index];
                return Column(
                  children: [
                    const SizedBox(
                      height: 20,
                    ),
                    Container(
                      alignment: Alignment.centerLeft,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: color,
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Text(
                          'Q${questionData?.questionNumber!}: ${questionData?.question!}',
                          style: const TextStyle(
                            fontSize: 35,
                            color: Colors.white,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    // ignore: avoid_function_literals_in_foreach_calls
                    for (Options opt in questionData?.options ?? [])
                      questionData?.responseType == 'single_choice'
                          ? RadioListTile(
                              title: Text(
                                opt.option.toString(),
                                style: const TextStyle(
                                    color: Colors.white, fontSize: 24),
                              ),
                              value: opt,
                              groupValue: optionalAnswers[index],
                              activeColor: color,
                              selectedTileColor: color,
                              onChanged: (value) {
                                setState(() {
                                  optionalAnswers[index] = value as Options;
                                  //_answers[index] = value as String;
                                });
                              },
                            )
                          : questionData?.responseType == 'multiple_choice'
                              ? CheckboxListTile(
                                  title: Text(
                                    opt.option.toString(),
                                    style: const TextStyle(
                                        color: Colors.white, fontSize: 24),
                                  ),
                                  value: true,
                                  activeColor: color,
                                  checkColor: Colors.white,
                                  onChanged: (value) {
                                    setState(() {
                                      optionalAnswers[index] = value as Options;
                                    });
                                  },
                                )
                              : Container(),

                    const SizedBox(
                      height: 20,
                    ),
                  ],
                );
              },
            ),
          ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(''),
            Padding(
              padding: const EdgeInsets.only(right: 60.0),
              child: ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    _formKey.currentState!.save();
                  }
                  print(optionalAnswers);
                  _submitAnswers();
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: color,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(40),
                  ),
                  padding:
                      const EdgeInsets.symmetric(vertical: 10, horizontal: 40),
                ),
                // ignore: prefer_const_constructors
                child: Padding(
                  padding: const EdgeInsets.only(left: 22.0, right: 22),
                  child: const Row(
                    // ignore: prefer_const_literals_to_create_immutables
                    children: [
                      Text(
                        'Submit',
                        style: TextStyle(
                          fontSize: 40,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(
          height: 32,
        ),
      ],
    );
  }
}
