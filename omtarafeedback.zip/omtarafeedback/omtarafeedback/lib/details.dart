// ignore_for_file: must_be_immutable, avoid_print

import 'package:flutter/material.dart';
import 'package:flutter_device_type/flutter_device_type.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:omtarafeedback/helpers/app_constant.dart';
import 'package:omtarafeedback/helpers/feedbackdetailfield.dart';
import 'package:omtarafeedback/helpers/helper_header.dart';
import 'package:omtarafeedback/model/specificFeedback.dart';
import 'package:omtarafeedback/services/api.dart';

class DetailScreen extends StatefulWidget {
  int id = 1;
  DetailScreen({Key? key, required this.id}) : super(key: key);

  @override
  State<DetailScreen> createState() => _DetailScreenState();
}

class _DetailScreenState extends State<DetailScreen> {
  final TextEditingController _purposeController = TextEditingController();
  FeedbackDetail? jsonList;
  final ApiClient _apiClient = ApiClient();

  @override
  @override
  void initState() {
    super.initState();
    callEndpoint();
  }

  Future<void> callEndpoint() async {
    context.loaderOverlay.show();
    await getData();
    // ignore: use_build_context_synchronously
    context.loaderOverlay.hide();
  }

  Future<void> getData() async {
    try {
      var response = await _apiClient.get(
        '$specificFeedbackEndpoint/${widget.id}',
        headers: header(),
      );
      print(response);
      if (response == null) {
        print("Empty response");
      }
      //jsonlist = response;

      try {
        SpecificFeedback feedback = SpecificFeedback.fromJson(response);
        if (feedback.success!) {
          if (feedback.data!.id != null) {
            setState(() {
              jsonList = feedback.data!;
              _purposeController.text = feedback.data?.comment != null
                  ? feedback.data?.comment ?? ''
                  : '';
            });
          }
        }
      } catch (e) {
        print(e);
      }
    } catch (e) {
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Stack(children: [
      Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/Visit-info-s.jpg'),
            fit: BoxFit.cover,
          ),
        ),
      ),
      SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.symmetric(
              horizontal: Device.get().isTablet ? 32.0 : 8, vertical: 16),
          child: jsonList?.id != null
              ? Column(
                  children: [
                    const SizedBox(height: 32),
                    StaticField(
                        resulttext: jsonList?.name ?? '', label: 'Name'),
                    const SizedBox(height: 32),
                    StaticField(
                        resulttext: jsonList?.phnNo ?? '',
                        label: 'Phone number'),
                    const SizedBox(height: 32),
                    StaticField(
                        resulttext: jsonList?.email ?? '', label: 'Email'),
                    const SizedBox(height: 32),
                    StaticField(resulttext: jsonList?.dob ?? '', label: 'Dob'),
                    const SizedBox(height: 32),
                    StaticField(
                        resulttext: jsonList?.wedDate ?? '', label: 'WedDate'),
                    const SizedBox(height: 32),
                    StaticField(
                        resulttext: jsonList?.rating != null
                            ? jsonList?.rating.toString() ?? '0'
                            : '0',
                        label: 'Rating'),
                    const SizedBox(height: 32),
                    StaticField(
                        resulttext: jsonList?.numOfPeople != null
                            ? jsonList?.numOfPeople.toString() ?? '0'
                            : '0',
                        label: 'Number of People'),
                    // const SizedBox(height: 32),
                    // Padding(
                    //   padding: const EdgeInsets.symmetric(horizontal: 32.0),
                    //   child: Container(
                    //     decoration: BoxDecoration(
                    //       borderRadius: BorderRadius.circular(0),
                    //       color: Colors.white,
                    //     ),
                    //     child: Row(
                    //       crossAxisAlignment: CrossAxisAlignment.center,
                    //       mainAxisAlignment: MainAxisAlignment.start,
                    //       children: [
                    //         Container(
                    //           decoration: BoxDecoration(
                    //             borderRadius: const BorderRadius.only(
                    //               topRight: Radius.circular(120),
                    //               bottomRight: Radius.circular(120),
                    //             ),
                    //             color: color,
                    //           ),
                    //           width: MediaQuery.of(context).size.width * .30,
                    //           height: 200,
                    //           child: const Padding(
                    //             padding: EdgeInsets.only(left: 16.0),
                    //             child: Align(
                    //               alignment: Alignment.centerLeft,
                    //               child: Text(
                    //                 'Comment',
                    //                 style: TextStyle(
                    //                     color: Colors.white,
                    //                     fontSize: 32,
                    //                     fontWeight: FontWeight.w500),
                    //                 textAlign: TextAlign.start,
                    //               ),
                    //             ),
                    //           ),
                    //         ),
                    //         Container(
                    //           width: MediaQuery.of(context).size.width * .60,
                    //           height: 200,
                    //           decoration: BoxDecoration(
                    //             color: const Color(0xFFFFE0B2),
                    //             borderRadius: BorderRadius.circular(10),
                    //           ),
                    //           child: TextFormField(
                    //             readOnly: true,
                    //             style: const TextStyle(fontSize: 20),
                    //             minLines: 8,
                    //             keyboardType: TextInputType.multiline,
                    //             maxLines: null,
                    //             controller: _purposeController,
                    //             decoration: InputDecoration(
                    //               hintStyle:
                    //                   const TextStyle(color: Colors.white),
                    //               filled: true,
                    //               fillColor: Colors.white,
                    //               border: OutlineInputBorder(
                    //                 borderRadius: BorderRadius.circular(10),
                    //                 borderSide: BorderSide.none,
                    //               ),
                    //             ),
                    //           ),
                    //         ),
                    //       ],
                    //     ),
                    //   ),
                    // ),

                    Visibility(
                      visible: true,
                      child: ListView.builder(
                        shrinkWrap: true,
                        physics: const BouncingScrollPhysics(),
                        itemCount: jsonList?.responses?.length ?? 0,
                        itemBuilder: (BuildContext context, int index) {
                          final questionData = jsonList?.responses?[index];
                          return Padding(
                            padding: EdgeInsets.symmetric(
                                horizontal: Device.get().isTablet ? 32.0 : 16),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                  height: Device.get().isTablet ? 20.0 : 8,
                                ),
                                Container(
                                  alignment: Alignment.centerLeft,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    color: color,
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(16.0),
                                    child: Text(
                                      '${questionData?.question!}',
                                      style: TextStyle(
                                        fontSize:
                                            Device.get().isTablet ? 35.0 : 18,
                                        color: Colors.white,
                                        fontWeight: FontWeight.w400,
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(
                                  height: 8,
                                ),
                                Container(
                                  alignment: Alignment.centerLeft,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    color: Colors.white,
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(16.0),
                                    child: Text(
                                      '${questionData?.option!}',
                                      style: TextStyle(
                                        fontSize:
                                            Device.get().isTablet ? 35.0 : 18,
                                        color: const Color(0xFFee7421),
                                        fontWeight: FontWeight.w400,
                                      ),
                                    ),
                                  ),
                                ),

                                // ignore: avoid_function_literals_in_foreach_calls

                                const SizedBox(
                                  height: 20,
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context, true);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: color,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(40),
                        ),
                        padding: const EdgeInsets.symmetric(
                            vertical: 10, horizontal: 40),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.only(left: 22.0, right: 22),
                        child: Text(
                          'Back',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: Device.get().isTablet ? 40 : 24,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 32),
                  ],
                )
              : const Center(child: Text('Feedback details not available')),
        ),
      )
    ]));
  }
}
