import "package:flutter/material.dart";

Color color = const Color(0xFFee7421);

const questionEndPoint = "getAllQuestions";
const visitorscreenoneEndPoint = "save_feedback";
const answersEndPoint = "feedback/addResponse";
const saveFeedBackEndPoint = 'save_feedback';
const ratingEndPoint = 'addRating';
const feebacktypeEndPoint = 'saveFeedbackType';
const specificFeedbackEndpoint = 'getSpecificFeedback';
const listFeedback = 'feedbackList';
const addVisitorDetailsEndPoint = 'addVisitorsDetails';
