import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:omtarafeedback/helpers/app_constant.dart';
// ignore: unused_import
import 'package:sizer/sizer.dart';
import 'package:flutter_device_type/flutter_device_type.dart';

class CalenderFields extends StatefulWidget {
  final TextEditingController controller;
  final String label;
  final String? Function(String?)? validator;

  const CalenderFields(
      {Key? key,
      required this.controller,
      required this.label,
      required this.validator})
      : super(key: key);

  @override
  State<CalenderFields> createState() => _CalenderFieldsState();
}

class _CalenderFieldsState extends State<CalenderFields> {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        color: Colors.white,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Container(
            decoration: BoxDecoration(
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(10),
                topRight: Radius.circular(30),
                bottomRight: Radius.circular(30),
                bottomLeft: Radius.circular(10),
              ),
              color: color,
            ),
            width: MediaQuery.of(context).size.width * .35,
            height: 70,
            child: Padding(
              padding: const EdgeInsets.only(left: 16.0),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  widget.label,
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: Device.get().isTablet ? 32 : 18,
                      fontWeight: FontWeight.w500),
                  textAlign: TextAlign.start,
                ),
              ),
            ),
          ),
          Container(
            width: MediaQuery.of(context).size.width * .60,
            height: 70,
            decoration: BoxDecoration(
              color: const Color(0xFFFFE0B2),
              borderRadius: BorderRadius.circular(10),
            ),
            child: InkWell(
              onTap: () async {
                DateTime? pickeddate = await showDatePicker(
                  context: context,
                  initialDate: DateTime.now(),
                  firstDate: DateTime(2000),
                  lastDate: DateTime.now(),
                );

                if (pickeddate != null) {
                  setState(() {
                    widget.controller.text =
                        DateFormat('yyyy-MM-dd').format(pickeddate);
                  });
                }
              },
              child: IgnorePointer(
                child: TextFormField(
                  style: TextStyle(
                    fontSize: Device.get().isTablet ? 32 : 18,
                  ),
                  controller: widget.controller,
                  validator: widget.validator,
                  decoration: InputDecoration(
                    hintStyle: TextStyle(
                      color: color,
                    ),
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
