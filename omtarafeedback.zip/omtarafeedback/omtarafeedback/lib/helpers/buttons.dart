import 'package:flutter/material.dart';
import 'package:omtarafeedback/helpers/app_constant.dart';


Widget myButton({
  required String text,
  required Function()?  tapped,
}) {
  return InkWell(
    onTap: tapped,
    child: Container(
      //child: Text(text),
      height: 60,width: 150,
                alignment: Alignment.center,
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(25),color: color),
                child: Text(text, style: const TextStyle(color: Colors.white,fontSize: 30),),
    ),
  );
}
