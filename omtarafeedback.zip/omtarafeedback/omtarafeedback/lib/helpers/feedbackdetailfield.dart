import 'package:flutter/material.dart';
import 'package:flutter_device_type/flutter_device_type.dart';
import 'package:omtarafeedback/helpers/app_constant.dart';

class StaticField extends StatelessWidget {
  final String resulttext;
  final String label;

  const StaticField({Key? key, required this.resulttext, required this.label})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding:
          EdgeInsets.symmetric(horizontal: Device.get().isTablet ? 32 : 16),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(0),
          color: Colors.white,
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Container(
              decoration: BoxDecoration(
                borderRadius: const BorderRadius.only(
                  topRight: Radius.circular(30),
                  bottomRight: Radius.circular(30),
                ),
                color: color,
              ),
              width: MediaQuery.of(context).size.width * .30,
              height: Device.get().isTablet ? 70 : 50,
              child: Padding(
                padding:
                    EdgeInsets.only(left: Device.get().isTablet ? 16.0 : 8),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    label,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: Device.get().isTablet ? 32.0 : 16,
                      fontWeight: FontWeight.w500,
                    ),
                    textAlign: TextAlign.start,
                  ),
                ),
              ),
            ),
            Container(
              width: MediaQuery.of(context).size.width *
                  (Device.get().isTablet ? .60 : .57),
              height: Device.get().isTablet ? 70 : 50,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Text(
                  resulttext,
                  style: TextStyle(
                    fontSize: Device.get().isTablet ? 32.0 : 16,
                    backgroundColor: Colors.white,
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
