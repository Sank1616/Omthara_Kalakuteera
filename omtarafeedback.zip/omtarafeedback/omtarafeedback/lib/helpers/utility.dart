import 'dart:convert';
import 'package:crypto/crypto.dart';

class Utility {
  static const String secretKey = "mysecretkey";
  static const String delemeter = "mydelimeter";

  static int getCurrentTime() {
    // ignore: avoid_print
    print('second:${DateTime.now().millisecondsSinceEpoch}');
    return DateTime.now().millisecondsSinceEpoch;
  }

  Digest encryptUsingSha(String input) {
    var appleInBytes = utf8.encode(input);
    Digest value = sha256.convert(appleInBytes);
    return value;
  }

  Future<String> generateAuthentication() async {
    int time = getCurrentTime();
    int tokenExpiretime = time + (60 * 1000);
    Digest encryptDelemeter = encryptUsingSha(delemeter);
    Digest beforeToken =
        encryptUsingSha('$secretKey$time$tokenExpiretime$encryptDelemeter');
    // ignore: avoid_print
    print('BeforeToken:$beforeToken');
    String token =
        '$time$encryptDelemeter$tokenExpiretime$encryptDelemeter$beforeToken';
    // ignore: avoid_print
    print('Token:$token');
    return token;
  }
}
