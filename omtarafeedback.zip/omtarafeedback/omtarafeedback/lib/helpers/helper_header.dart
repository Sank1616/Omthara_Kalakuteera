Map<String, String> header() {
  return {"Content-Type": "application/json", "Accept": "application/json"};
}

Map<String, String> authheader(String token) {
  return {
    "Content-Type": "application/json",
    "Accept": "application/json",
    "Authorization": token
  };
}
