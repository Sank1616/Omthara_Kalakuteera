import 'package:flutter/material.dart';
import 'package:flutter_device_type/flutter_device_type.dart';
import 'package:omtarafeedback/helpers/app_constant.dart';

class InputField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  // ignore: non_constant_identifier_names
  final double FontSize;
  final String? Function(String?)? validator;

  const InputField(
      {Key? key,
      required this.controller,
      required this.label,
      required this.validator,
      // ignore: non_constant_identifier_names
      required this.FontSize})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: Colors.white,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Container(
            decoration: BoxDecoration(
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(10),
                bottomLeft: Radius.circular(10),
                topRight: Radius.circular(30),
                bottomRight: Radius.circular(30),
              ),
              color: color,
            ),
            width: MediaQuery.of(context).size.width * .35,
            height: 70,
            child: Padding(
              padding: const EdgeInsets.only(left: 16.0),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  label,
                  style: TextStyle(
                    color: Colors.white,
                    //fontSize: FontSize,
                    fontSize: FontSize,
                    fontWeight: FontWeight.w500,
                  ),
                  textAlign: TextAlign.start,
                ),
              ),
            ),
          ),
          Container(
            width: MediaQuery.of(context).size.width *
                (Device.get().isTablet ? .60 : .60),
            height: 70,
            decoration: BoxDecoration(
              color: const Color(0xFFFFE0B2),
              borderRadius: BorderRadius.circular(10),
            ),
            child: TextFormField(
              style: TextStyle(fontSize: Device.get().isTablet ? 30 : 18),
              controller: controller,
              validator: validator,
              decoration: InputDecoration(
                hintStyle: TextStyle(
                  color: color,
                ),
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
