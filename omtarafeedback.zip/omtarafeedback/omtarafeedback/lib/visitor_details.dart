// ignore_for_file: use_build_context_synchronously

import 'package:flutter/material.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:omtarafeedback/feedback_page.dart';
import 'package:omtarafeedback/helpers/app_constant.dart';
import 'package:omtarafeedback/helpers/fields.dart';
import 'package:omtarafeedback/helpers/helper_header.dart';
import 'package:omtarafeedback/helpers/responsiveWidget.dart';
import 'package:omtarafeedback/helpers/utility.dart';
import 'package:omtarafeedback/services/api.dart';
import 'helpers/global.dart' as global;

class VisitorDetails extends StatefulWidget {
  const VisitorDetails({Key? key}) : super(key: key);

  @override
  State<VisitorDetails> createState() => _VisitorDetailsState();
}

class _VisitorDetailsState extends State<VisitorDetails> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _noController = TextEditingController();
  final TextEditingController _purposeController = TextEditingController();
  final ApiClient _apiClient = ApiClient();

  Future<void> _submitAnswers() async {
    context.loaderOverlay.show();
    await uploadAnswer();
    context.loaderOverlay.hide();
  }

  Future<void> uploadAnswer() async {
    String au = await Utility().generateAuthentication();
    try {
      var response = await _apiClient
          .post(addVisitorDetailsEndPoint, headers: authheader(au), body: {
        'num_of_people': _noController.text,
        'feedback_id': global.feedbackId,
        'comment': _purposeController.text
      });
      if (response == null) {
        // ignore: avoid_print
        print("Empty response");
      }
      try {
        // ignore: avoid_print
        print(response);
        Navigator.of(context)
            .push(MaterialPageRoute(builder: (context) => const FeedBack()));
      } catch (e) {
        // ignore: avoid_print
        print("Erro:${e.toString()}");
      }
    } catch (e) {
      // ignore: avoid_print
      print("Erro:${e.toString()}");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage("assets/Visit-info-s.jpg"),
                fit: BoxFit.fill,
              ),
            ),
          ),
          InkWell(
            onTap: () {
              FocusScope.of(context).unfocus();
            },
            child: SingleChildScrollView(
              child: responsiveWidget(
                  mobile: detailsPhone(context), tab: detailsTab(context)),
            ),
          )
        ],
      ),
    );
  }

  Form detailsTab(BuildContext context) {
    return Form(
      key: _formKey,
      child: Padding(
        padding: const EdgeInsets.only(top: 32.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            const SizedBox(
              height: 32,
            ),
            Row(
              children: [
                const SizedBox(
                  width: 25,
                ),
                Container(
                  alignment: Alignment.center,
                  height: 50,
                  width: 250,
                  decoration: BoxDecoration(
                      color: color, borderRadius: BorderRadius.circular(10)),
                  child: const Text(
                    'Visit Details',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                const SizedBox(
                  width: 820,
                ),
                Container(
                  padding: const EdgeInsets.all(08),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: color,
                  ),
                  child: Text(
                    '${DateTime.now().day}/${DateTime.now().month}/${DateTime.now().year}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 32),
            Row(children: [
              const SizedBox(width: 25),
              InputField(
                FontSize: 32,
                controller: _noController,
                label: 'Number of People',
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'This field cannot be empty';
                  }
                  return null;
                },
              ),
              //SizedBox(width: 10,)
            ]),
            const SizedBox(height: 32),
            Row(children: [
              const SizedBox(
                width: 25,
              ),
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: Colors.white,
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    //SizedBox(width :25),
                    Row(children: [
                      //SizedBox(width: 25,),
                      Container(
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(20),
                            bottomLeft: Radius.circular(20),
                            topRight: Radius.circular(120),
                            bottomRight: Radius.circular(120),
                          ),
                          color: color,
                        ),
                        width: MediaQuery.of(context).size.width * .35,
                        height: 200,
                        child: const Padding(
                          padding: EdgeInsets.only(left: 16.0),
                          child: Align(
                            alignment: Alignment.centerLeft,
                            child: Text(
                              'Purpose of the Visit',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 32,
                                  fontWeight: FontWeight.w500),
                              textAlign: TextAlign.start,
                            ),
                          ),
                        ),
                      ),
                    ]),
                    Container(
                      width: MediaQuery.of(context).size.width * .60,
                      height: 200,
                      decoration: BoxDecoration(
                        color: const Color(0xFFFFE0B2),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: TextFormField(
                        style: const TextStyle(fontSize: 20),
                        minLines: 8,
                        keyboardType: TextInputType.multiline,
                        maxLines: null,
                        controller: _purposeController,
                        decoration: InputDecoration(
                          hintStyle: const TextStyle(color: Colors.white),
                          filled: true,
                          fillColor: Colors.white,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: BorderSide.none,
                          ),
                        ),
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'This field cannot be empty!!';
                          }
                          return null;
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ]),
            const SizedBox(
              height: 84,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                ElevatedButton(
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      _submitAnswers();
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: color,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(40),
                    ),
                    padding: const EdgeInsets.symmetric(
                        vertical: 10, horizontal: 40),
                  ),
                  // ignore: prefer_const_constructors
                  child: Padding(
                    padding: const EdgeInsets.only(left: 22.0, right: 22),
                    child: const Row(
                      // ignore: prefer_const_literals_to_create_immutables
                      children: [
                        Text(
                          'Next',
                          style: TextStyle(
                            fontSize: 40,
                            //fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(
                          width: 24,
                        ),
                        Icon(
                          Icons.arrow_forward,
                          color: Colors.white,
                          size: 50,
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(
                  width: 25,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Form detailsPhone(BuildContext context) {
    return Form(
      key: _formKey,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            const SizedBox(
              height: 60,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 0.0),
                  child: Container(
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                        color: color, borderRadius: BorderRadius.circular(10)),
                    child: const Padding(
                      padding: EdgeInsets.all(12.0),
                      child: Text(
                        'Visit Details',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ),
                Container(
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: color,
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: Text(
                      '${DateTime.now().day}/${DateTime.now().month}/${DateTime.now().year}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            Row(
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 15),
                  child: SizedBox(
                    height: 55,
                    child: InputField(
                      FontSize: 20,
                      controller: _noController,
                      label: 'Number of People',
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'This field cannot be empty';
                        }
                        return null;
                      },
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.only(right: 4.0),
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Colors.white,
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      //width: 50,
                      decoration: BoxDecoration(
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(10),
                          bottomLeft: Radius.circular(10),
                          topRight: Radius.circular(120),
                          bottomRight: Radius.circular(120),
                        ),
                        color: color,
                      ),
                      width: MediaQuery.of(context).size.width * .35,
                      height: 200,
                      child: const Padding(
                        padding: EdgeInsets.only(left: 16.0),
                        child: Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            'Purpose of the Visit',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 22,
                                fontWeight: FontWeight.w500),
                            textAlign: TextAlign.start,
                          ),
                        ),
                      ),
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width * .58,
                      height: 200,
                      decoration: BoxDecoration(
                        color: const Color(0xFFFFE0B2),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: TextFormField(
                        style: const TextStyle(fontSize: 20),
                        minLines: 8,
                        keyboardType: TextInputType.multiline,
                        maxLines: null,
                        controller: _purposeController,
                        decoration: InputDecoration(
                          hintStyle: const TextStyle(color: Colors.white),
                          filled: true,
                          fillColor: Colors.white,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: BorderSide.none,
                          ),
                        ),
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'This field cannot be empty!!';
                          }
                          return null;
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(
              height: 34,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Container(
                  margin: const EdgeInsets.only(top: 20, right: 10),
                  child: ElevatedButton(
                    onPressed: () {
                      if (_formKey.currentState!.validate()) {
                        _submitAnswers();
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: color,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(40),
                      ),
                      padding: const EdgeInsets.symmetric(
                        vertical: 10,
                      ),
                    ),
                    child: const Padding(
                      padding: EdgeInsets.only(left: 20.0, right: 30),
                      child: Row(
                        // ignore: prefer_const_literals_to_create_immutables
                        children: [
                          Padding(
                            padding: EdgeInsets.only(left: 15, right: 2),
                            child: Text(
                              'Next',
                              style: TextStyle(
                                fontSize: 25,
                                //fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 14,
                          ),
                          Icon(
                            Icons.arrow_forward,
                            color: Colors.white,
                            size: 25,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ),

  // )));
}



 //
  //   return Form(
  //             key: _formKey,
  //             child: Column(
  //               crossAxisAlignment: CrossAxisAlignment.start,
  //               children: [
  //                 const SizedBox(
  //                   height: 32,
  //                 ),
  //                 Row(
  //                   children: [
  //                     Text(
  //                       'Visit Details',
  //                       style: TextStyle(
  //                         color: color,
  //                         fontSize: 32,
  //                         fontWeight: FontWeight.bold,
  //                       ),
  //                     ),
  //                     const SizedBox(
  //                       width: 820,
  //                     ),
  //                     Container(
  //                       padding: const EdgeInsets.all(08),
  //                       decoration: BoxDecoration(
  //                         borderRadius: BorderRadius.circular(10),
  //                         color: color,
  //                       ),
  //                       child: Text(
  //                         '${DateTime.now().day}/${DateTime.now().month}/${DateTime.now().year}',
  //                         style: const TextStyle(
  //                           color: Colors.white,
  //                           fontSize: 24,
  //                           fontWeight: FontWeight.bold,
  //                         ),
  //                       ),
  //                     ),
  //                   ],
  //                 ),
  //                 const SizedBox(height: 32),
  //                 InputField(
  //                   controller: _noController,
  //                   label: 'Number of People',
  //                   validator: (value) {
  //                     if (value!.isEmpty) {
  //                       return 'This field cannot be empty';
  //                     }
  //                     return null;
  //                   },
  //                 ),
  //                 const SizedBox(height: 32),
  //                 Container(
  //                   decoration: BoxDecoration(
  //                     borderRadius: BorderRadius.circular(0),
  //                     color: Colors.white,
  //                   ),
  //                   child: Row(
  //                     crossAxisAlignment: CrossAxisAlignment.center,
  //                     mainAxisAlignment: MainAxisAlignment.start,
  //                     children: [
  //                       Container(
  //                         decoration: BoxDecoration(
  //                           borderRadius: const BorderRadius.only(
  //                             topRight: Radius.circular(120),
  //                             bottomRight: Radius.circular(120),
  //                           ),
  //                           color: color,
  //                         ),
  //                         width: MediaQuery.of(context).size.width * .30,
  //                         height: 200,
  //                         child: const Padding(
  //                           padding: EdgeInsets.only(left: 16.0),
  //                           child: Align(
  //                             alignment: Alignment.centerLeft,
  //                             child: Text(
  //                               'Purpose of the Visit',
  //                               style: TextStyle(
  //                                   color: Colors.white,
  //                                   fontSize: 32,
  //                                   fontWeight: FontWeight.w500),
  //                               textAlign: TextAlign.start,
  //                             ),
  //                           ),
  //                         ),
  //                       ),
  //                       Container(
  //                         width: MediaQuery.of(context).size.width * .60,
  //                         height: 200,
  //                         decoration: BoxDecoration(
  //                           color: const Color(0xFFFFE0B2),
  //                           borderRadius: BorderRadius.circular(10),
  //                         ),
  //                         child: TextFormField(
  //                           style: const TextStyle(fontSize: 20),
  //                           minLines: 8,
  //                           keyboardType: TextInputType.multiline,
  //                           maxLines: null,
  //                           controller: _purposeController,
  //                           decoration: InputDecoration(
  //                             hintStyle: const TextStyle(color: Colors.white),
  //                             filled: true,
  //                             fillColor: Colors.white,
  //                             border: OutlineInputBorder(
  //                               borderRadius: BorderRadius.circular(10),
  //                               borderSide: BorderSide.none,
  //                             ),
  //                           ),
  //                           validator: (value) {
  //                             if (value!.isEmpty) {
  //                               return 'This field cannot be empty!!';
  //                             }
  //                             return null;
  //                           },
  //                         ),
  //                       ),
  //                     ],
  //                   ),
  //                 ),
  //                 const SizedBox(
  //                   height: 64,
  //                 ),
  //                 Row(
  //                   mainAxisAlignment: MainAxisAlignment.end,
  //                   children: [
  //                     ElevatedButton(
  //                       onPressed: () {
  //                         if (_formKey.currentState!.validate()) {
  //                           _submitAnswers();
  //                         }
  //                       },
  //                       style: ElevatedButton.styleFrom(
  //                         backgroundColor: color,
  //                         shape: RoundedRectangleBorder(
  //                           borderRadius: BorderRadius.circular(40),
  //                         ),
  //                         padding: const EdgeInsets.symmetric(
  //                             vertical: 10, horizontal: 40),
  //                       ),
  //                       child: Padding(
  //                         padding:
  //                             const EdgeInsets.only(left: 22.0, right: 22),
  //                         child: Row(
  //                           // ignore: prefer_const_literals_to_create_immutables
  //                           children: [
  //                             const Text(
  //                               'Next',
  //                               style: TextStyle(
  //                                 fontSize: 40,
  //                                 //fontWeight: FontWeight.bold,
  //                               ),
  //                             ),
  //                             const SizedBox(
  //                               width: 24,
  //                             ),
  //                             const Icon(
  //                               Icons.arrow_forward,
  //                               color: Colors.white,
  //                               size: 50,
  //                             ),
  //                           ],
  //                         ),
  //                       ),
  //                     ),
  //                   ],
  //                 ),
  //               ],
  //             ),
  //           );
  // }

