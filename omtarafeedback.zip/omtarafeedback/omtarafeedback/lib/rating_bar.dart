// ignore_for_file: use_build_context_synchronously, non_constant_identifier_names

import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:omtarafeedback/helpers/helper_header.dart';
import 'package:omtarafeedback/helpers/responsiveWidget.dart';
import 'package:omtarafeedback/helpers/utility.dart';
import 'package:omtarafeedback/services/api.dart';
import 'package:omtarafeedback/thankyou_screen.dart';
import 'package:omtarafeedback/helpers/app_constant.dart';
import 'helpers/global.dart' as global;
import 'helpers/buttons.dart';

class RatingBarScreen extends StatefulWidget {
  const RatingBarScreen({Key? key}) : super(key: key);

  @override
  State<RatingBarScreen> createState() => _RatingBarScreenState();
}

class _RatingBarScreenState extends State<RatingBarScreen> {
  double fullRating = 0;
  double halfRating = 0;
  double emojiRating = 0;

  final ApiClient _apiClient = ApiClient();

  Future<void> _submitRating() async {
    context.loaderOverlay.show();
    await uploadRating();
    context.loaderOverlay.hide();
  }

  Future<void> uploadRating() async {
    String au = await Utility().generateAuthentication();
    try {
      var response = await _apiClient.post(ratingEndPoint,
          headers: authheader(au),
          body: {'rating': halfRating, 'feedback_id': global.feedbackId});
      if (response == null) {
        // ignore: avoid_print
        print("Empty response");
      }
      try {
        if (response['success']) {
          // ignore: avoid_print
          print(response);
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) {
              return const ThankYou();
            }),
          );
        }
      } catch (e) {
        // ignore: avoid_print
        print("Erro:${e.toString()}");
      }
    } catch (e) {
      // ignore: avoid_print
      print("Erro:${e.toString()}");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: DecoratedBox(
      // BoxDecoration takes the image
      decoration: const BoxDecoration(
        // Image set to background of the body
        image: DecorationImage(
            colorFilter: ColorFilter.mode(Colors.black, BlendMode.dstATop),
            image: AssetImage("assets/rating-s.jpg"),
            fit: BoxFit.cover),
      ),

      child: responsiveWidget(mobile: ratingPhone(), tab: RatingTab()),
    ));
  }

  Column ratingPhone() {
    return Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Container(
        height: 100,
        width: 300,
        alignment: Alignment.center,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30), color: color),
        child: const Text('Ratings',
            style: TextStyle(fontSize: 50, color: Colors.white)),
      ),
      const SizedBox(
        height: 60,
      ),
      Center(
        child: Container(
          height: 150,
          width: 350,
          alignment: Alignment.center,
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(30), color: color),
          child: RatingBar.builder(
            initialRating: 0,
            minRating: 1,
            allowHalfRating: true,
            unratedColor: Colors.white,
            itemCount: 5,
            itemSize: 60.0,
            itemPadding: const EdgeInsets.symmetric(horizontal: 4.0),
            updateOnDrag: true,
            itemBuilder: (context, index) => const Icon(
              Icons.star,
              color: Colors.yellow,
            ),
            onRatingUpdate: (ratingvalue) {
              setState(() {
                halfRating = ratingvalue;
              });
            },
          ),
        ),
      ),
      const SizedBox(height: 80),
      Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
        myButton(
            text: 'Submit',
            tapped: () {
              _submitRating();
            }),
        // const SizedBox(
        //   width: 50,
        // )
      ])
    ]);
  }

  Column RatingTab() {
    return Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Container(
        height: 100,
        width: 300,
        alignment: Alignment.center,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30), color: color),
        child: const Text('Ratings',
            style: TextStyle(fontSize: 50, color: Colors.white)),
      ),
      const SizedBox(
        height: 60,
      ),
      Center(
        child: Container(
          height: 350,
          width: 1100,
          alignment: Alignment.center,
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(60), color: color),
          child: RatingBar.builder(
            initialRating: 0,
            minRating: 1,
            allowHalfRating: true,
            unratedColor: Colors.white,
            itemCount: 5,
            itemSize: 150.0,
            itemPadding: const EdgeInsets.symmetric(horizontal: 4.0),
            updateOnDrag: true,
            itemBuilder: (context, index) => const Icon(
              Icons.star,
              color: Colors.yellow,
            ),
            onRatingUpdate: (ratingvalue) {
              setState(() {
                halfRating = ratingvalue;
              });
            },
          ),
        ),
      ),
      const SizedBox(
        height: 100,
      ),
      Row(mainAxisAlignment: MainAxisAlignment.end, children: [
        myButton(
            text: 'Submit',
            tapped: () {
              _submitRating();
            }),
        const SizedBox(
          width: 50,
        )
      ])
    ]);
  }
}
